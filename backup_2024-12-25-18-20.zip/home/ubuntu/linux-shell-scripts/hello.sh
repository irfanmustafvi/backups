#!/bin/bash

echo "hell friends"

echo "welcome to DevOps"

date

whoami

# If don't want in error while creating dir always use mkdir -p <dirname>
